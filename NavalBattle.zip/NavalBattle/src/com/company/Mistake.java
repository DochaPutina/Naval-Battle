package com.company;

public class Mistake {
    int Dermo;
}
