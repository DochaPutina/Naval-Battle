package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class Game {

    static char[] Alph = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'};

    static String Name1;

    static String Name2;

    static Scanner Scanner = new Scanner(System.in);

    static void FillField(Field Poliana) {
        for (int i = 0; i < Poliana.Boards; i++) {
            for (int j = 0; j < Poliana.Boards; j++) {
                Kletka cell = new Kletka(1, 1);
                cell.IPosition = i;
                cell.JPosition = j;
                Poliana.Pole[i][j] = cell;
            }
        }
    }

    //2-есть корабль(не подбит), 3-есть корабль(подбит), 1-нет корабля(1-клетка не подбита, 2-клетка подбита)
    static void CheckField(Field Poliana, int iPosition, int jPosition) {
        if (Poliana.Pole[iPosition][jPosition].DegreeOfSurvivability == 3) {
            System.out.print(" ☒");
        } else if (Poliana.Pole[iPosition][jPosition].DegreeOfSurvivability == 2) {
            System.out.print("|▆");
        } else if (Poliana.Pole[iPosition][jPosition].DegreeOfSurvivability == 1) {
            if (Poliana.Pole[iPosition][jPosition].PastOrHit == 1) {
                System.out.print("|_");
            } else if (Poliana.Pole[iPosition][jPosition].PastOrHit == 2) {
                System.out.print("|∙");
            }
        }
    }

    static void PaintField(Field Poliana) {
        for (int i = 0; i < 12; i++) {
            for (int j = 0; j < 12; j++) {
                switch (i) {
                    case 0:
                        switch (j) {
                            default:
                                System.out.print(" ");
                                break;
                            case 2:
                                System.out.print(" " + Alph[0] + " ");
                                break;
                            case 3:
                                System.out.print(Alph[1] + " ");
                                break;
                            case 4:
                                System.out.print(Alph[2] + " ");
                                break;
                            case 5:
                                System.out.print(Alph[3] + " ");
                                break;
                            case 6:
                                System.out.print(Alph[4] + " ");
                                break;
                            case 7:
                                System.out.print(Alph[5] + " ");
                                break;
                            case 8:
                                System.out.print(Alph[6] + " ");
                                break;
                            case 9:
                                System.out.print(Alph[7] + " ");
                                break;
                            case 10:
                                System.out.print(Alph[8] + " ");
                                break;
                            case 11:
                                System.out.print(Alph[9] + " ");
                                System.out.println();
                                break;
                        }
                        break;
                    case 1:
                        switch (j) {
                            default:
                                System.out.print("__");
                                break;
                            case 0:
                                System.out.print(" ");
                                break;
                            case 1:
                                System.out.print("  ");
                                break;
                            case 11:
                                System.out.print("_");
                                System.out.println();
                                break;
                        }
                        break;
                    case 2:
                        switch (j) {
                            case 0:
                                System.out.print(1 + " ");

                                break;
                            case 11:
                                System.out.print("|");
                                System.out.println();
                                break;
                            default:
                                CheckField(Poliana, i - 2, j - 1);
                                break;
                        }
                        break;
                    case 3:
                        switch (j) {
                            case 0:
                                System.out.print(2 + " ");
                                break;
                            case 11:
                                System.out.print("|");
                                System.out.println();
                                break;
                            default:
                                CheckField(Poliana, i - 2, j - 1);
                                break;
                        }
                        break;
                    case 4:
                        switch (j) {
                            case 0:
                                System.out.print(3 + " ");
                                break;
                            case 11:
                                System.out.print("|");
                                System.out.println();
                                break;
                            default:
                                CheckField(Poliana, i - 2, j - 1);
                                break;
                        }
                        break;
                    case 5:
                        switch (j) {
                            case 0:
                                System.out.print(4 + " ");
                                break;
                            case 11:
                                System.out.print("|");
                                System.out.println();
                                break;
                            default:
                                CheckField(Poliana, i - 2, j - 1);
                                break;
                        }
                        break;
                    case 6:
                        switch (j) {
                            case 0:
                                System.out.print(5 + " ");
                                break;
                            case 11:
                                System.out.print("|");
                                System.out.println();
                                break;
                            default:
                                CheckField(Poliana, i - 2, j - 1);
                                break;
                        }
                        break;
                    case 7:
                        switch (j) {
                            case 0:
                                System.out.print(6 + " ");
                                break;
                            case 11:
                                System.out.print("|");
                                System.out.println();
                                break;
                            default:
                                CheckField(Poliana, i - 2, j - 1);
                                break;
                        }
                        break;
                    case 8:
                        switch (j) {
                            case 0:
                                System.out.print(7 + " ");
                                break;
                            case 11:
                                System.out.print("|");
                                System.out.println();
                                break;
                            default:
                                CheckField(Poliana, i - 2, j - 1);
                                break;
                        }
                        break;
                    case 9:
                        switch (j) {
                            case 0:
                                System.out.print(8 + " ");
                                break;
                            case 11:
                                System.out.print("|");
                                System.out.println();
                                break;
                            default:
                                CheckField(Poliana, i - 2, j - 1);
                                break;
                        }
                        break;
                    case 10:
                        switch (j) {
                            case 0:
                                System.out.print(9 + " ");
                                break;
                            case 11:
                                System.out.print("|");
                                System.out.println();
                                break;
                            default:
                                CheckField(Poliana, i - 2, j - 1);
                                break;
                        }
                        break;
                    case 11:
                        switch (j) {
                            case 0:
                                System.out.print(10);
                                break;
                            case 11:
                                System.out.print("|");
                                System.out.println();
                                break;
                            default:
                                CheckField(Poliana, i - 2, j - 1);
                                break;
                        }
                        break;
                }
            }
        }
    }

    static int Converter(String JsPosition1) {
        int JPosition = -1;
        char JsPosition = JsPosition1.charAt(0);
        for (int i = 0; i < Alph.length; i++) {
            if (Alph[i] == JsPosition) {
                JPosition = i;
            }
        }
        return JPosition;
    }

    static void Delete(Kletka Case, Field Poliana, Ship[] AllShips) {
        for (int i = 0; i < AllShips.length; i++) {
            for (int j = 0; j < AllShips[i].ForShip.size(); j++) {
                if (AllShips[i].ForShip.get(j).IPosition == Case.IPosition && AllShips[i].ForShip.get(j).JPosition == Case.JPosition) {
                    AllShips[i].ForShip.remove(j);
                }
            }
        }
        for (int i = 0; i < Poliana.Boards; i++) {
            for (int j = 0; j < Poliana.Boards; j++) {
                if (Poliana.Pole[i][j].IPosition == Case.IPosition && Poliana.Pole[i][j].JPosition == Case.JPosition) {
                    Poliana.Pole[i][j].DegreeOfSurvivability = 1;
                }
            }
        }
    }

    static boolean CheckKletka(Field Poliana, Kletka Case, Ship CheckShip) {
        boolean Answer = true;
        int y = 0;
        Outer:
        if (y == 0) {
            switch (Case.IPosition) {
                case 0:
                    switch (Case.JPosition) {
                        case 0:
                            for (int i = 0; i < 4; i++) {
                                switch (i) {
                                    case 0:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition][Case.JPosition + 1]) == -1 && Poliana.Pole[Case.IPosition][Case.JPosition + 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 1:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition + 1][Case.JPosition + 1]) == -1 && Poliana.Pole[Case.IPosition + 1][Case.JPosition + 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 2:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition + 1][Case.JPosition]) == -1 && Poliana.Pole[Case.IPosition + 1][Case.JPosition].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                }
                            }
                            break;
                        case 9:
                            for (int i = 0; i < 3; i++) {
                                switch (i) {
                                    case 0:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition + 1][Case.JPosition]) == -1 && Poliana.Pole[Case.IPosition + 1][Case.JPosition].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 1:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition + 1][Case.JPosition - 1]) == -1 && Poliana.Pole[Case.IPosition + 1][Case.JPosition - 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 2:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition][Case.JPosition - 1]) == -1 && Poliana.Pole[Case.IPosition][Case.JPosition - 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                }
                            }
                            break;
                        default:
                            for (int i = 0; i < 5; i++) {
                                switch (i) {
                                    case 0:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition][Case.JPosition + 1]) == -1 && Poliana.Pole[Case.IPosition][Case.JPosition + 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 1:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition + 1][Case.JPosition + 1]) == -1 && Poliana.Pole[Case.IPosition + 1][Case.JPosition + 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 2:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition + 1][Case.JPosition]) == -1 && Poliana.Pole[Case.IPosition + 1][Case.JPosition].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 3:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition + 1][Case.JPosition - 1]) == -1 && Poliana.Pole[Case.IPosition + 1][Case.JPosition - 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 4:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition][Case.JPosition - 1]) == -1 && Poliana.Pole[Case.IPosition][Case.JPosition - 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                }
                            }
                            break;

                    }
                    break;
                case 9:
                    switch (Case.JPosition) {
                        case 0:
                            for (int i = 0; i < 3; i++) {
                                switch (i) {
                                    case 0:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition - 1][Case.JPosition]) == -1 && Poliana.Pole[Case.IPosition - 1][Case.JPosition].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 1:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition - 1][Case.JPosition + 1]) == -1 && Poliana.Pole[Case.IPosition - 1][Case.JPosition + 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 2:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition][Case.JPosition + 1]) == -1 && Poliana.Pole[Case.IPosition][Case.JPosition + 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                }
                            }
                            break;
                        case 9:
                            for (int i = 0; i < 3; i++) {
                                switch (i) {
                                    case 0:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition][Case.JPosition - 1]) == -1 && Poliana.Pole[Case.IPosition][Case.JPosition - 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 1:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition - 1][Case.JPosition - 1]) == -1 && Poliana.Pole[Case.IPosition - 1][Case.JPosition - 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 2:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition - 1][Case.JPosition]) == -1 && Poliana.Pole[Case.IPosition - 1][Case.JPosition].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                }
                            }
                            break;
                        default:
                            for (int i = 0; i < 5; i++) {
                                switch (i) {
                                    case 0:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition][Case.JPosition - 1]) == -1 && Poliana.Pole[Case.IPosition][Case.JPosition - 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 1:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition - 1][Case.JPosition - 1]) == -1 && Poliana.Pole[Case.IPosition - 1][Case.JPosition - 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 2:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition - 1][Case.JPosition]) == -1 && Poliana.Pole[Case.IPosition - 1][Case.JPosition].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 3:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition - 1][Case.JPosition + 1]) == -1 && Poliana.Pole[Case.IPosition - 1][Case.JPosition + 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 4:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition][Case.JPosition + 1]) == -1 && Poliana.Pole[Case.IPosition][Case.JPosition + 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                }
                            }
                            break;
                    }
                    break;
                default:
                    switch (Case.JPosition) {
                        case 0:
                            for (int i = 0; i < 5; i++) {
                                switch (i) {
                                    case 0:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition - 1][Case.JPosition]) == -1 && Poliana.Pole[Case.IPosition - 1][Case.JPosition].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 1:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition - 1][Case.JPosition + 1]) == -1 && Poliana.Pole[Case.IPosition - 1][Case.JPosition + 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 2:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition][Case.JPosition + 1]) == -1 && Poliana.Pole[Case.IPosition][Case.JPosition + 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 3:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition + 1][Case.JPosition + 1]) == -1 && Poliana.Pole[Case.IPosition + 1][Case.JPosition + 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 4:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition + 1][Case.JPosition]) == -1 && Poliana.Pole[Case.IPosition + 1][Case.JPosition].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                }
                            }
                            break;
                        case 9:
                            for (int i = 0; i < 5; i++) {
                                switch (i) {
                                    case 0:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition + 1][Case.JPosition]) == -1 && Poliana.Pole[Case.IPosition + 1][Case.JPosition].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 1:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition + 1][Case.JPosition - 1]) == -1 && Poliana.Pole[Case.IPosition + 1][Case.JPosition - 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 2:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition][Case.JPosition - 1]) == -1 && Poliana.Pole[Case.IPosition][Case.JPosition - 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 3:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition - 1][Case.JPosition - 1]) == -1 && Poliana.Pole[Case.IPosition - 1][Case.JPosition - 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 4:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition - 1][Case.JPosition]) == -1 && Poliana.Pole[Case.IPosition - 1][Case.JPosition].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                }
                            }
                            break;
                        default:
                            for (int i = 0; i < 8; i++) {
                                switch (i) {
                                    case 0:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition][Case.JPosition - 1]) == -1 && Poliana.Pole[Case.IPosition][Case.JPosition - 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 1:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition - 1][Case.JPosition - 1]) == -1 && Poliana.Pole[Case.IPosition - 1][Case.JPosition - 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 2:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition - 1][Case.JPosition]) == -1 && Poliana.Pole[Case.IPosition - 1][Case.JPosition].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 3:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition - 1][Case.JPosition + 1]) == -1 && Poliana.Pole[Case.IPosition - 1][Case.JPosition + 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 4:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition][Case.JPosition + 1]) == -1 && Poliana.Pole[Case.IPosition][Case.JPosition + 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 5:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition + 1][Case.JPosition + 1]) == -1 && Poliana.Pole[Case.IPosition + 1][Case.JPosition + 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 6:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition + 1][Case.JPosition]) == -1 && Poliana.Pole[Case.IPosition + 1][Case.JPosition].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                    case 7:
                                        if (CheckShip.ForShip.indexOf(Poliana.Pole[Case.IPosition + 1][Case.JPosition - 1]) == -1 && Poliana.Pole[Case.IPosition + 1][Case.JPosition - 1].DegreeOfSurvivability == 2) {
                                            Answer = false;
                                            y++;
                                            break Outer;
                                        }
                                        break;
                                }
                            }
                            break;
                    }
                    break;
            }
        }
        return Answer;
    }

    static boolean CheckShip(Field Poliana, Ship WhatCheck, Ship[] AllShips) {
        boolean Answer = true;
        for (int i = 0; i < WhatCheck.ForShip.size(); i++) {
            if (!CheckKletka(Poliana, WhatCheck.ForShip.get(i), WhatCheck)) {
                for (int j = 0; j < WhatCheck.ForShip.size(); j++) {
                    Delete(WhatCheck.ForShip.get(0), Poliana, AllShips);
                }
                Answer = false;
            }
        }
        Outer:
        for (int i = 0; i < WhatCheck.ForShip.size(); i++) {
            for (int j = 0; j < AllShips.length; j++) {
                for (int k = 0; k < AllShips[j].ForShip.size(); k++) {
                    if (AllShips[j].ForShip.get(k).IPosition == WhatCheck.ForShip.get(i).IPosition && AllShips[j].ForShip.get(k).JPosition == WhatCheck.ForShip.get(i).JPosition && WhatCheck != AllShips[j]) {
                        Answer = false;
                        break Outer;
                    }
                }
            }
        }
        return Answer;
    }

    static boolean CheckEnter(int i1, int j1, int i2, int j2) {
        boolean Answer = true;
        if (i1 != i2 && j1 != j2) Answer = false;
        return Answer;
    }

    static boolean CheckEnterPalubniy(int i1, int j1, int i2, int j2, int KolVoPalubniy) {
        boolean Answer = true;
        if (i1 == i2 && j1 <= j2) {
            if (j2 - (j1 - 1) != KolVoPalubniy) {
                Answer = false;
            }
        } else if (i1 == i2 && j1 > j2) {
            if (j1 - (j2 - 1) != KolVoPalubniy) {
                Answer = false;
            }
        } else if (j1 == j2 && i1 <= i2) {
            if (i2 - (i1 - 1) != KolVoPalubniy) {
                Answer = false;
            }
        } else if (j1 == j2 && i1 > i2) {
            if (i1 - (i2 - 1) != KolVoPalubniy) {
                Answer = false;
            }
        }
        return Answer;
    }

    static Ship[] FillShips(Ship[] AllShips) {
        for (int i = 0; i < 10; i++) {
            if (i == 0) {
                Ship Korable = new Ship(4);
                AllShips[i] = Korable;
            } else if (1 == i || 2 == i) {
                Ship Korable1 = new Ship(3);
                AllShips[i] = Korable1;
            } else if (i == 3 || i == 4 || i == 5) {
                Ship Korable2 = new Ship(2);
                AllShips[i] = Korable2;
            } else if (i == 6 || i == 7 || i == 8 || i == 9) {
                Ship Korable3 = new Ship(1);
                AllShips[i] = Korable3;
            }
        }
        return AllShips;
    }

    static void ChangeAll(int IPosition, int JPosition, Field PoleAtak, Field PoleDefense, Ship[] Allships, int ForWhat, int Where) {
        if (Where == 0) {
            PoleAtak.Pole[IPosition][JPosition].DegreeOfSurvivability = ForWhat;
            PoleDefense.Pole[IPosition][JPosition].DegreeOfSurvivability = ForWhat;
            for (int i = 0; i < Allships.length; i++) {
                for (int j = 0; j < Allships[i].ForShip.size(); j++) {
                    if (Allships[i].ForShip.get(j).IPosition == IPosition && Allships[i].ForShip.get(j).JPosition == JPosition) {
                        Allships[i].ForShip.get(j).DegreeOfSurvivability = ForWhat;
                        return;
                    }
                }
            }
        } else if (Where == 1) {
            PoleAtak.Pole[IPosition][JPosition].PastOrHit = ForWhat;
            PoleDefense.Pole[IPosition][JPosition].PastOrHit = ForWhat;
        }
    }

    static boolean HaveAShip(int IPosition, int JPosition, Field PoleDefense) {
        boolean Answer = false;
        if (PoleDefense.Pole[IPosition][JPosition].DegreeOfSurvivability == 2) Answer = true;
        return Answer;
    }

    static boolean HaveAShip2(int IPosition, int JPosition, Field PoleDefense) {
        boolean Answer = false;
        if (PoleDefense.Pole[IPosition][JPosition].DegreeOfSurvivability == 3) Answer = true;
        return Answer;
    }

    static void Turn(int IPosition, int JPosition, Field PoleAtak, Field PoleDefense, Ship[] Allships) {
        int ForWhat;
        int Where;
        if (HaveAShip(IPosition, JPosition, PoleDefense)) {
            ForWhat = 3;
            Where = 0;
            ChangeAll(IPosition, JPosition, PoleAtak, PoleDefense, Allships, ForWhat, Where);
            return;
        } else if (!HaveAShip(IPosition, JPosition, PoleDefense)) {
            ForWhat = 2;
            Where = 1;
            ChangeAll(IPosition, JPosition, PoleAtak, PoleDefense, Allships, ForWhat, Where);
            return;
        }
    }

    static void StartForFirstPlayer(Field PoleDefense1, Ship[] AllShips1) {
        int IdKorable;
        int i1Position;
        int j1Position;
        int i2Position;
        int j2Position;
        System.out.println("Введите имя игрока 1 (вводите в одно слово) ");
        String[] Command = Scanner.nextLine().split(" ");
        Name1 = Command[0];
        PaintField(PoleDefense1);
        System.out.println("Добро пожаловать в игру " + Name1);
        System.out.println("Если вы хотите получить помощь, введите: Помощь");
        while (true) {
            try {
                String[] Command1 = Scanner.nextLine().split(" ");
                if (Command1[0].equals("Помощь")) {
                    System.out.println("Если вы хотите поставить четырёхпалубник, то введите: Поставить четырёхпалубник");
                    System.out.println("Если вы хотите поставить трёхпалубник, то введите: Поставить трёхпалубник");
                    System.out.println("Если вы хотите поставить двухпалубник, то введите: Поставить двухпалубник");
                    System.out.println("Если вы хотите поставить однопалубник, то введите: Поставить однопалубник");
                    System.out.println("Если вы хотите удалить корабль, введите: Удалить");
                    System.out.println("Если вы хотите закончить расстановку, введите: Закончить");
                } else if (Command1[0].equals("Удалить")) {
                    System.out.println("Введите координаты корабля");
                    Command1 = Scanner.nextLine().split(" ");
                    i1Position = Integer.parseInt(Command1[1]) - 1;
                    j1Position = Converter(Command1[0]);
                    i2Position = Integer.parseInt(Command1[3]) - 1;
                    j2Position = Converter(Command1[2]);
                    if (CheckEnter(i1Position, j1Position, i2Position, j2Position) && DelCheck(i1Position, j1Position, i2Position, j2Position, PoleDefense1) && FullDelCheck(i1Position, j1Position, i2Position, j2Position, AllShips1)) {
                        FullDelete(i1Position, j1Position, i2Position, j2Position, PoleDefense1, AllShips1);
                        PaintField(PoleDefense1);
                        System.out.println("Корабль успешно удалён");
                    } else {
                        Mistake gop = null;
                        gop.Dermo = 3;
                    }
                } else if (Command1[0].equals("Поставить")) {
                    Outer:
                    switch (Command1[1]) {
                        case "четырёхпалубник":
                            if (!CheckShipHave(4, AllShips1)) {
                                System.out.println("Этот корабль уже поставлен, если хотите удалить, введите: Удалить");
                                break Outer;
                            }
                            System.out.println(Name1 + ", пожалуйста введите координаты четырёхпалубника. Например: a 4 a 1");
                            Command1 = Scanner.nextLine().split(" ");
                            i1Position = Integer.parseInt(Command1[1]) - 1;
                            j1Position = Converter(Command1[0]);
                            i2Position = Integer.parseInt(Command1[3]) - 1;
                            j2Position = Converter(Command1[2]);
                            if (i1Position < 0 || i1Position >= 10 || i2Position < 0 || i2Position >= 10 || j1Position == -1 || j2Position == -1 || !CheckEnter(i1Position, j1Position, i2Position, j2Position) || !CheckEnterPalubniy(i1Position, j1Position, i2Position, j2Position, 4)) {
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            Add(PoleDefense1, AllShips1, i1Position, j1Position, i2Position, j2Position, 0);
                            if (!CheckShip(PoleDefense1, AllShips1[0], AllShips1)) {
                                CheckShip(PoleDefense1, AllShips1[0], AllShips1);
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            PaintField(PoleDefense1);
                            System.out.println("Корабль поставлен, если хотите его удалить, введите: Удалить");
                            break;
                        case "трёхпалубник":
                            if (!CheckShipHave(3, AllShips1)) {
                                System.out.println("Трёхпалубники уже раставлены, если хотите удалить, введите: Удалить");
                                break Outer;
                            }
                            System.out.println(Name1 + ", пожалуйста введите координаты трёхпалубника. Например: a 3 a 1");
                            Command1 = Scanner.nextLine().split(" ");
                            i1Position = Integer.parseInt(Command1[1]) - 1;
                            j1Position = Converter(Command1[0]);
                            i2Position = Integer.parseInt(Command1[3]) - 1;
                            j2Position = Converter(Command1[2]);
                            if (i1Position < 0 || i1Position >= 10 || i2Position < 0 || i2Position >= 10 || j1Position == -1 || j2Position == -1 || !CheckEnter(i1Position, j1Position, i2Position, j2Position) || !CheckEnterPalubniy(i1Position, j1Position, i2Position, j2Position, 3)) {
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            IdKorable = FindFreeShip(3, AllShips1);
                            Add(PoleDefense1, AllShips1, i1Position, j1Position, i2Position, j2Position, IdKorable);
                            if (!CheckShip(PoleDefense1, AllShips1[IdKorable], AllShips1)) {
                                CheckShip(PoleDefense1, AllShips1[IdKorable], AllShips1);
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            PaintField(PoleDefense1);
                            System.out.println("Корабль поставлен, если хотите его удалить, введите: Удалить");
                            break;
                        case "двухпалубник":
                            if (!CheckShipHave(2, AllShips1)) {
                                System.out.println("Двухпалубники уже раставлены, если хотите удалить, введите: Удалить");
                                break Outer;
                            }
                            System.out.println(Name1 + ", пожалуйста введите координаты двухпалубника. Например: a 2 a 1");
                            Command1 = Scanner.nextLine().split(" ");
                            i1Position = Integer.parseInt(Command1[1]) - 1;
                            j1Position = Converter(Command1[0]);
                            i2Position = Integer.parseInt(Command1[3]) - 1;
                            j2Position = Converter(Command1[2]);
                            if (i1Position < 0 || i1Position >= 10 || i2Position < 0 || i2Position >= 10 || j1Position == -1 || j2Position == -1 || !CheckEnter(i1Position, j1Position, i2Position, j2Position) || !CheckEnterPalubniy(i1Position, j1Position, i2Position, j2Position, 2)) {
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            IdKorable = FindFreeShip(2, AllShips1);
                            Add(PoleDefense1, AllShips1, i1Position, j1Position, i2Position, j2Position, IdKorable);
                            if (!CheckShip(PoleDefense1, AllShips1[IdKorable], AllShips1)) {
                                CheckShip(PoleDefense1, AllShips1[IdKorable], AllShips1);
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            PaintField(PoleDefense1);
                            System.out.println("Корабль поставлен, если хотите его удалить, введите: Удалить");
                            break;
                        case "однопалубник":
                            if (!CheckShipHave(1, AllShips1)) {
                                System.out.println("Однопалубники уже раставлены, если хотите удалить, введите: Удалить");
                                break Outer;
                            }
                            System.out.println(Name1 + ", пожалуйста введите координаты однопалубника. Например: a 1 a 1");
                            Command1 = Scanner.nextLine().split(" ");
                            i1Position = Integer.parseInt(Command1[1]) - 1;
                            j1Position = Converter(Command1[0]);
                            i2Position = Integer.parseInt(Command1[3]) - 1;
                            j2Position = Converter(Command1[2]);
                            if (i1Position < 0 || i1Position >= 10 || i2Position < 0 || i2Position >= 10 || j1Position == -1 || j2Position == -1 || !CheckEnter(i1Position, j1Position, i2Position, j2Position) || !CheckEnterPalubniy(i1Position, j1Position, i2Position, j2Position, 1)) {
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            IdKorable = FindFreeShip(1, AllShips1);
                            Add(PoleDefense1, AllShips1, i1Position, j1Position, i2Position, j2Position, IdKorable);
                            if (!CheckShip(PoleDefense1, AllShips1[IdKorable], AllShips1)) {
                                CheckShip(PoleDefense1, AllShips1[IdKorable], AllShips1);
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            PaintField(PoleDefense1);
                            System.out.println("Корабль поставлен, если хотите его удалить, введите: Удалить");
                            break;
                    }
                } else if (Command1[0].equals("Закончить")) {
                    if (CheckEndOfStart(AllShips1)) {
                        break;
                    } else {
                        System.out.println("Вы расставили не все корабли");
                    }
                }
            } catch (Exception MAMA) {
                System.out.println("Ой, вы кажется ошиблись. Попробуйте снова.");

            }

        }
    }

    static void StartForSecondPlayer(Field PoleDefense2, Ship[] AllShips2) {
        int IdKorable;
        int i1Position;
        int j1Position;
        int i2Position;
        int j2Position;
        System.out.println("Введите имя игрока 2 (вводите в одно слово) ");
        String[] Command = Scanner.nextLine().split(" ");
        Name2 = Command[0];
        PaintField(PoleDefense2);
        System.out.println("Добро пожаловать в игру " + Name2);
        System.out.println("Если вы хотите получить помощь, введите: Помощь");
        while (true) {
            try {
                String[] Command1 = Scanner.nextLine().split(" ");
                if (Command1[0].equals("Помощь")) {
                    System.out.println("Если вы хотите поставить четырёхпалубник, то введите: Поставить четырёхпалубник");
                    System.out.println("Если вы хотите поставить трёхпалубник, то введите: Поставить трёхпалубник");
                    System.out.println("Если вы хотите поставить двухпалубник, то введите: Поставить двухпалубник");
                    System.out.println("Если вы хотите поставить однопалубник, то введите: Поставить однопалубник");
                    System.out.println("Если вы хотите удалить корабль, введите: Удалить");
                    System.out.println("Если вы хотите закончить расстановку, введите: Закончить");
                } else if (Command1[0].equals("Удалить")) {
                    System.out.println("Введите координаты корабля");
                    Command1 = Scanner.nextLine().split(" ");
                    i1Position = Integer.parseInt(Command1[1]) - 1;
                    j1Position = Converter(Command1[0]);
                    i2Position = Integer.parseInt(Command1[3]) - 1;
                    j2Position = Converter(Command1[2]);
                    if (CheckEnter(i1Position, j1Position, i2Position, j2Position) && DelCheck(i1Position, j1Position, i2Position, j2Position, PoleDefense2) && FullDelCheck(i1Position, j1Position, i2Position, j2Position, AllShips2)) {
                        FullDelete(i1Position, j1Position, i2Position, j2Position, PoleDefense2, AllShips2);
                        PaintField(PoleDefense2);
                        System.out.println("Корабль успешно удалён");
                    } else {
                        Mistake gop = null;
                        gop.Dermo = 3;
                    }
                } else if (Command1[0].equals("Поставить")) {
                    Outer:
                    switch (Command1[1]) {
                        case "четырёхпалубник":
                            if (!CheckShipHave(4, AllShips2)) {
                                System.out.println("Этот корабль уже поставлен, если хотите удалить, введите: Удалить");
                                break Outer;
                            }
                            System.out.println(Name1 + ", пожалуйста введите координаты четырёхпалубника. Например: a 4 a 1");
                            Command1 = Scanner.nextLine().split(" ");
                            i1Position = Integer.parseInt(Command1[1]) - 1;
                            j1Position = Converter(Command1[0]);
                            i2Position = Integer.parseInt(Command1[3]) - 1;
                            j2Position = Converter(Command1[2]);
                            if (i1Position < 0 || i1Position >= 10 || i2Position < 0 || i2Position >= 10 || j1Position == -1 || j2Position == -1 || !CheckEnter(i1Position, j1Position, i2Position, j2Position) || !CheckEnterPalubniy(i1Position, j1Position, i2Position, j2Position, 4)) {
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            Add(PoleDefense2, AllShips2, i1Position, j1Position, i2Position, j2Position, 0);
                            if (!CheckShip(PoleDefense2, AllShips2[0], AllShips2)) {
                                CheckShip(PoleDefense2, AllShips2[0], AllShips2);
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            PaintField(PoleDefense2);
                            System.out.println("Корабль поставлен, если хотите его удалить, введите: Удалить");
                            break;
                        case "трёхпалубник":
                            if (!CheckShipHave(3, AllShips2)) {
                                System.out.println("Трёхпалубники уже раставлены, если хотите удалить, введите: Удалить");
                                break Outer;
                            }
                            System.out.println(Name1 + ", пожалуйста введите координаты трёхпалубника. Например: a 3 a 1");
                            Command1 = Scanner.nextLine().split(" ");
                            i1Position = Integer.parseInt(Command1[1]) - 1;
                            j1Position = Converter(Command1[0]);
                            i2Position = Integer.parseInt(Command1[3]) - 1;
                            j2Position = Converter(Command1[2]);
                            if (i1Position < 0 || i1Position >= 10 || i2Position < 0 || i2Position >= 10 || j1Position == -1 || j2Position == -1 || !CheckEnter(i1Position, j1Position, i2Position, j2Position) || !CheckEnterPalubniy(i1Position, j1Position, i2Position, j2Position, 3)) {
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            IdKorable = FindFreeShip(3, AllShips2);
                            Add(PoleDefense2, AllShips2, i1Position, j1Position, i2Position, j2Position, IdKorable);
                            if (!CheckShip(PoleDefense2, AllShips2[IdKorable], AllShips2)) {
                                CheckShip(PoleDefense2, AllShips2[IdKorable], AllShips2);
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            PaintField(PoleDefense2);
                            System.out.println("Корабль поставлен, если хотите его удалить, введите: Удалить");
                            break;
                        case "двухпалубник":
                            if (!CheckShipHave(2, AllShips2)) {
                                System.out.println("Двухпалубники уже раставлены, если хотите удалить, введите: Удалить");
                                break Outer;
                            }
                            System.out.println(Name1 + ", пожалуйста введите координаты двухпалубника. Например: a 2 a 1");
                            Command1 = Scanner.nextLine().split(" ");
                            i1Position = Integer.parseInt(Command1[1]) - 1;
                            j1Position = Converter(Command1[0]);
                            i2Position = Integer.parseInt(Command1[3]) - 1;
                            j2Position = Converter(Command1[2]);
                            if (i1Position < 0 || i1Position >= 10 || i2Position < 0 || i2Position >= 10 || j1Position == -1 || j2Position == -1 || !CheckEnter(i1Position, j1Position, i2Position, j2Position) || !CheckEnterPalubniy(i1Position, j1Position, i2Position, j2Position, 2)) {
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            IdKorable = FindFreeShip(2, AllShips2);
                            Add(PoleDefense2, AllShips2, i1Position, j1Position, i2Position, j2Position, IdKorable);
                            if (!CheckShip(PoleDefense2, AllShips2[IdKorable], AllShips2)) {
                                CheckShip(PoleDefense2, AllShips2[IdKorable], AllShips2);
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            PaintField(PoleDefense2);
                            System.out.println("Корабль поставлен, если хотите его удалить, введите: Удалить");
                            break;
                        case "однопалубник":
                            if (!CheckShipHave(1, AllShips2)) {
                                System.out.println("Однопалубники уже раставлены, если хотите удалить, введите: Удалить");
                                break Outer;
                            }
                            System.out.println(Name1 + ", пожалуйста введите координаты однопалубника. Например: a 1 a 1");
                            Command1 = Scanner.nextLine().split(" ");
                            i1Position = Integer.parseInt(Command1[1]) - 1;
                            j1Position = Converter(Command1[0]);
                            i2Position = Integer.parseInt(Command1[3]) - 1;
                            j2Position = Converter(Command1[2]);
                            if (i1Position < 0 || i1Position >= 10 || i2Position < 0 || i2Position >= 10 || j1Position == -1 || j2Position == -1 || !CheckEnter(i1Position, j1Position, i2Position, j2Position) || !CheckEnterPalubniy(i1Position, j1Position, i2Position, j2Position, 1)) {
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            IdKorable = FindFreeShip(1, AllShips2);
                            Add(PoleDefense2, AllShips2, i1Position, j1Position, i2Position, j2Position, IdKorable);
                            if (!CheckShip(PoleDefense2, AllShips2[IdKorable], AllShips2)) {
                                CheckShip(PoleDefense2, AllShips2[IdKorable], AllShips2);
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            PaintField(PoleDefense2);
                            System.out.println("Корабль поставлен, если хотите его удалить, введите: Удалить");
                            break;
                    }
                } else if (Command1[0].equals("Закончить")) {
                    if (CheckEndOfStart(AllShips2)) {
                        break;
                    } else {
                        System.out.println("Вы расставили не все корабли");
                    }
                }
            } catch (Exception MAMA) {
                System.out.println("Ой, вы кажется ошиблись. Попробуйте снова.");

            }

        }
    }

    static ArrayList<Kletka> FindArraylistInShips(int i1, int j1, Ship[] AllShips) {
        ArrayList<Kletka> Answer = new ArrayList<Kletka>();
        Outer:
        for (int i = 0; i < AllShips.length; i++) {
            for (int j = 0; j < AllShips[i].ForShip.size(); j++) {
                if (AllShips[i].ForShip.get(j).IPosition == i1 && AllShips[i].ForShip.get(j).JPosition == j1) {
                    Answer = AllShips[i].ForShip;
                    break Outer;
                }
            }
        }
        return Answer;
    }

    static int CheckNextTurn(Ship[] AllShips1, Ship[] AllShips2) {
        int Answer = 0;//0- никто не победил, 1- победил второй, 2- победил первый.
        boolean Fst = false;
        boolean Snd = false;
        for (int i = 0; i < AllShips1.length; i++) {
            for (int j = 0; j < AllShips1[i].ForShip.size(); j++) {
                if (AllShips1[i].ForShip.get(j).DegreeOfSurvivability == 2) {
                    Fst = true;
                    break;
                }
            }
        }
        for (int i = 0; i < AllShips2.length; i++) {
            for (int j = 0; j < AllShips2[i].ForShip.size(); j++) {
                if (AllShips2[i].ForShip.get(j).DegreeOfSurvivability == 2) {
                    Snd = true;
                    break;
                }
            }
        }
        if (!Fst) Answer = 2;
        else if (!Snd) Answer = 1;
        return Answer;
    }

    static boolean CheckEnterForTurn(Field Pole, int IPosition, int JPosition) {
        boolean Answer = true;
        if (Pole.Pole[IPosition][JPosition].DegreeOfSurvivability == 3 || Pole.Pole[IPosition][JPosition].PastOrHit == 2) {
            Answer = false;
        }
        return Answer;
    }

    static boolean CheckEndOfStart(Ship[] AllShips) {
        boolean Answer = true;
        for (int i = 0; i < AllShips.length; i++) {
            if (AllShips[i].ForShip.size() == 0) {
                Answer = false;
            }
        }
        return Answer;
    }

    static boolean FullDelCheck(int i1From, int j1From, int i2To, int j2To, Ship[] AllShips) {
        ArrayList<Kletka> WhereCheck = FindArraylistInShips(i1From, j1From, AllShips);
        boolean Answer = true;
        for (int i = 0; i < WhereCheck.size(); i++) {
            if (i1From == i2To) {
                if (j2To >= j1From) {
                    for (int j = j1From; j <= j2To; j++) {
                        if (WhereCheck.get(i).IPosition == i1From && WhereCheck.get(i).JPosition == j) {
                            WhereCheck.remove(i);
                        }
                    }
                } else {
                    for (int j = j2To; j < j1From; j++) {
                        if (WhereCheck.get(i).IPosition == i1From && WhereCheck.get(i).JPosition == j) {
                            WhereCheck.remove(i);
                        }
                    }
                }
            } else {
                if (i1From <= i2To) {
                    for (int j = i1From; j <= i2To; j++) {
                        if (WhereCheck.get(i).IPosition == j && WhereCheck.get(i).JPosition == j1From) {
                            WhereCheck.remove(i);
                        }
                    }
                } else {
                    for (int j = i2To; j < i1From; j++) {
                        if (WhereCheck.get(i).IPosition == j && WhereCheck.get(i).JPosition == j1From) {
                            WhereCheck.remove(i);
                        }
                    }
                }
            }
        }
        if (WhereCheck.size() != 0) Answer = false;
        return Answer;
    }

    static void FullDelete(int i1, int j1, int i2, int j2, Field Poliana, Ship[] AllShips) {
        if (i1 == i2) {
            if (j1 <= j2) {
                for (int i = j1; i <= j2; i++) {
                    Delete(Poliana.Pole[i1][i], Poliana, AllShips);
                }
            } else if (j1 > j2) {
                for (int i = j2; i <= j1; i++) {
                    Delete(Poliana.Pole[i1][i], Poliana, AllShips);
                }
            }
        } else if (j1 == j2) {
            if (i1 <= i2) {
                for (int i = i1; i <= i2; i++) {
                    Delete(Poliana.Pole[i][j1], Poliana, AllShips);
                }
            } else if (i1 > i2) {
                for (int i = i2; i <= i1; i++) {
                    Delete(Poliana.Pole[i][j1], Poliana, AllShips);
                }
            }
        }
    }

    static int FindFreeShip(int KolVoPulubniy, Ship[] AllShips) {
        int Answer = -1;
        for (int i = 0; i < AllShips.length; i++) {
            if (AllShips[i].ForShip.size() == 0 && AllShips[i].KolvoPulub == KolVoPulubniy) {
                Answer = i;
            }
        }
        return Answer;
    }

    static boolean CheckShipHave(int KolVoPulubniy, Ship[] AllShips) {
        boolean Answer = false;
        for (int i = 0; i < AllShips.length; i++) {
            if (AllShips[i].ForShip.size() == 0 && AllShips[i].KolvoPulub == KolVoPulubniy) {
                Answer = true;
            }
        }
        return Answer;
    }

    static boolean DelCheck(int i1, int j1, int i2, int j2, Field Pole) {
        boolean Answer = true;
        Outer:
        if (i1 == i2) {
            if (j1 <= j2) {
                for (int i = j1; i <= j2; i++) {
                    if (Pole.Pole[i1][i].DegreeOfSurvivability == 1) {
                        Answer = false;
                        break Outer;
                    }
                }
            } else if (j1 > j2) {
                for (int i = j2; i < j1; i++) {
                    if (Pole.Pole[i1][i].DegreeOfSurvivability == 1) {
                        Answer = false;
                        break Outer;
                    }
                }
            }
        } else if (j1 == j2) {
            if (i1 <= i2) {
                for (int i = i1; i <= i2; i++) {
                    if (Pole.Pole[i][j1].DegreeOfSurvivability == 1) {
                        Answer = false;
                        break Outer;
                    }
                }
            } else if (i1 > i2) {
                for (int i = i2; i < i1; i++) {
                    if (Pole.Pole[i][j1].DegreeOfSurvivability == 1) {
                        Answer = false;
                        break Outer;
                    }
                }
            }
        }
        return Answer;
    }


    static void Add(Field Poliana, Ship[] AllShips, int i1, int j1, int i2, int j2, int IndexOfShip) {
        if (i1 == i2) {
            if (j1 < j2) {
                for (int i = j1; i <= j2; i++) {
                    Poliana.Pole[i1][i].DegreeOfSurvivability = 2;

                    AllShips[IndexOfShip].ForShip.add(Poliana.Pole[i1][i]);
                }
            } else {
                for (int i = j2; i <= j1; i++) {
                    Poliana.Pole[i1][i].DegreeOfSurvivability = 2;
                    AllShips[IndexOfShip].ForShip.add(Poliana.Pole[i1][i]);
                }
            }
        } else if (j1 == j2) {
            if (i1 < i2) {
                for (int i = i1; i <= i2; i++) {
                    Poliana.Pole[i][j1].DegreeOfSurvivability = 2;
                    AllShips[IndexOfShip].ForShip.add(Poliana.Pole[i][j1]);
                }
            } else {
                for (int i = i2; i <= i1; i++) {
                    Poliana.Pole[i][j1].DegreeOfSurvivability = 2;
                    AllShips[IndexOfShip].ForShip.add(Poliana.Pole[i][j1]);
                }
            }
        }
    }

    public static void main(String[] args) {
        Field PoleAtak1 = new Field();
        Field PoleAtak2 = new Field();
        Field PoleDefense1 = new Field();
        Field PoleDefense2 = new Field();
        Ship[] AllShips1 = new Ship[10];
        Ship[] AllShips2 = new Ship[10];
        int turn = 0;
        FillShips(AllShips1);
        FillShips(AllShips2);
        FillField(PoleAtak1);
        FillField(PoleAtak2);
        FillField(PoleDefense1);
        FillField(PoleDefense2);
        StartForFirstPlayer(PoleDefense1, AllShips1);
        StartForSecondPlayer(PoleDefense2, AllShips2);
        System.out.println("Итак, игра началась!");
        int IPosition;
        int JPosition;
        String[] Command;
        while (true) {
            try {
                if (CheckNextTurn(AllShips1, AllShips2) == 2) {
                    System.out.println(Name1 + " победил, игра окончена!");
                    break;
                } else if (CheckNextTurn(AllShips1, AllShips2) == 1) {
                    System.out.println(Name2 + " победил, игра окончена!");
                    break;
                } else {
                    switch (turn) {
                        case 0:
                            System.out.println("Ход игрока " + Name1);
                            System.out.println("Введите координаты выстрела, например: a 1");
                            Command = Scanner.nextLine().split(" ");
                            IPosition = Integer.parseInt(Command[1]) - 1;
                            JPosition = Converter(Command[0]);
                            if (IPosition < 0 || IPosition > 9 || JPosition < 0 || JPosition > 9 || !CheckEnterForTurn(PoleAtak2, IPosition, JPosition)) {
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            Turn(IPosition, JPosition, PoleAtak2, PoleDefense2, AllShips2);
                            if (HaveAShip2(IPosition, JPosition, PoleDefense2)) {
                                System.out.println("Вы попали по короблю");
                            } else {
                                System.out.println("Промах");
                                turn = 1;
                            }
                            PaintField(PoleAtak2);
                            break;
                        case 1:
                            System.out.println("Ход игрока " + Name2);
                            System.out.println("Введите координаты выстрела, например: a 1");
                            Command = Scanner.nextLine().split(" ");
                            IPosition = Integer.parseInt(Command[1]) - 1;
                            JPosition = Converter(Command[0]);
                            if (IPosition < 0 || IPosition > 9 || JPosition < 0 || JPosition > 9 || !CheckEnterForTurn(PoleAtak1, IPosition, JPosition)) {
                                Mistake gop = null;
                                gop.Dermo = 3;
                            }
                            Turn(IPosition, JPosition, PoleAtak1, PoleDefense1, AllShips1);
                            if (HaveAShip(IPosition, JPosition, PoleDefense1)) {
                                System.out.println("Вы попали по короблю");
                                PaintField(PoleAtak1);
                            } else {
                                System.out.println("Промах");
                                turn = 1;
                                PaintField(PoleAtak1);
                            }
                    }
                }
            } catch (Exception MAMA) {
                System.out.println("Ой, вы кажется ошиблись. Попробуйте снова.");
                MAMA.printStackTrace();
            }
        }
    }
}

