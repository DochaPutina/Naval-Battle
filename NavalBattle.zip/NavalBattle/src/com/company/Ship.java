package com.company;

import java.util.ArrayList;

public class Ship {
    ArrayList<Kletka> ForShip = new ArrayList<Kletka>();
    boolean LifeOrDie = false;
    int KolvoPulub;

    public Ship(int KolvoPulub) {
        this.KolvoPulub = KolvoPulub;
    }

    @Override
    public String toString() {
        return ForShip + "   " + KolvoPulub;
    }
}
