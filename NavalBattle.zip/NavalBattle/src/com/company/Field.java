package com.company;

public class Field {
    final int Boards =10;
    Kletka [][] Pole=new Kletka[Boards][Boards];
}
