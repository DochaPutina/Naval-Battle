package com.company;

public class Kletka {
    int DegreeOfSurvivability;
    int PastOrHit;
    int IPosition;
    int JPosition;


    public Kletka(int DegreeOfSurvivability,int PastOrHit) {
        this.DegreeOfSurvivability = DegreeOfSurvivability;
        this.PastOrHit=PastOrHit;
    }

    @Override
    public String toString() {
        return DegreeOfSurvivability+"  1";

    }
}
